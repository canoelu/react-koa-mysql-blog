const config = {
    // 启动端口
    port: 3600,
    // 数据库配置
    'secret': '0a6b944d-d2fb-46fc-a85e-0295c986cd9f',
    'database': 'mongodb://127.0.0.1:27017/blog'
}

module.exports = config